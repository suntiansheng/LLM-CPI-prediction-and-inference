#library(readr)
result <- read.csv("result/t_distribution_Sign_result.csv")
result <- as.matrix(result)
#rbind(true_MSE_result[1:4,]/true_MSE_result[1,])

relative_m <- rbind(sweep(result[1:4,], 2, result[1,,drop=FALSE], "/"),
      sweep(result[5:8,], 2, result[5,,drop=FALSE], "/"),
      sweep(result[9:12,], 2, result[9,,drop=FALSE], "/"),
      sweep(result[13:16,], 2, result[13,,drop=FALSE], "/"))


relative_m <- data.frame(relative_m)
relative_m <- round(relative_m, 3)
relative_m <- cbind(rep(c('AR', 'RW','AVG','LLM-CPI'), 4), relative_m)
relative_m <- cbind(rep(seq(0.1,0.4, length.out = 4), each = 4), relative_m)
colnames(relative_m) <- c('rho','H', seq(8,15,1))
relative_m
#colnames(relative_m) <- cbind(rep(seq(0.1,0.4, length.out = 4), each = 4), relative_m)


### For interval result


result <- read.csv("result/t_distribution_len_result.csv")
result <- as.matrix(result)
#rbind(true_MSE_result[1:4,]/true_MSE_result[1,])


result <- data.frame(result)
result <- round(result, 3)
result <- cbind(rep(c('AR', 'LLM-BJ','LLM-BOOT'), 4), result)
result <- cbind(rep(seq(0.1,0.4, length.out = 4), each = 3), result)
colnames(result) <- c('rho','H', seq(8,15,1))
result
